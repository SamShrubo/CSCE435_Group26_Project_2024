/******************************************************************************
* FILE: columnsort.cpp
* DESCRIPTION:
* AUTHOR: Griffin Beaudreau
* LAST REVISED: 10/14/2024
*******************************************************************************/

#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <caliper/cali.h>
#include <caliper/cali-manager.h>
#include <adiak.hpp>

#define MASTER 0

int compare_int(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

int main(int argc, char* argv[]) {
    CALI_CXX_MARK_FUNCTION;

    MPI_Init(&argc, &argv);
    int taskid, numtasks;
    MPI_Comm_rank(MPI_COMM_WORLD, &taskid);
    MPI_Comm_size(MPI_COMM_WORLD, &numtasks);

    // Expected arguments: program name, N
    if (argc != 2) {
        if (taskid == MASTER) {
            printf("Usage: %s <size_of_input>\n", argv[0]);
        }
        MPI_Finalize();
        return 0;
    }

    int N = atoi(argv[1]);
    int P = numtasks; // Number of processors
    
    int rows = (N + P - 1) / P;
    int N_padded = rows * P;
    int padding_size = N_padded - N;

    int* local_array = (int*)malloc(rows * sizeof(int));
    if (taskid == MASTER) {
        int* global_data = (int*)malloc(N_padded * sizeof(int));
        for (int i = 0; i < N; ++i) {
            global_data[i] = rand() % 1000; // Fake data for now
        }

        for (int i = N; i < N_padded; ++i) {
            global_data[i] = INT_MAX; // Padding
        }

        for (int p = 0; p < P; ++p) {
            if (p == MASTER) {
                memcpy(local_array, &global_data[p * rows], rows * sizeof(int));
            } else {
                MPI_Send(&global_data[p * rows], rows, MPI_INT, p, 0, MPI_COMM_WORLD);
            }
        }
        free(global_data);
    } else {
        MPI_Recv(local_array, rows, MPI_INT, MASTER, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }

    CALI_MARK_BEGIN("Local_column_sort");
    qsort(local_array, rows, sizeof(int), compare_int);
    CALI_MARK_END("Local_column_sort");

    CALI_MARK_BEGIN("Transpose");
    int* transpose_array = (int*)malloc(rows * sizeof(int));
    for (int i = 0; i < rows; ++i) {
        int element = local_array[i];
        MPI_Allgather(&element, 1, MPI_INT, transpose_array, 1, MPI_INT, MPI_COMM_WORLD);
        local_array[i] = transpose_array[taskid];
    }
    free(transpose_array);
    CALI_MARK_END("Transpose");

    CALI_MARK_BEGIN("Local_row_sort");
    qsort(local_array, rows, sizeof(int), compare_int);
    CALI_MARK_END("Local_row_sort");

    CALI_MARK_BEGIN("Transpose");
    transpose_array = (int*)malloc(rows * sizeof(int));
    for (int i = 0; i < rows; ++i) {
        int element = local_array[i];
        MPI_Allgather(&element, 1, MPI_INT, transpose_array, 1, MPI_INT, MPI_COMM_WORLD);
        local_array[i] = transpose_array[taskid];
    }
    free(transpose_array);
    CALI_MARK_END("Transpose");

    CALI_MARK_BEGIN("Local_column_sort");
    qsort(local_array, rows, sizeof(int), compare_int);
    CALI_MARK_END("Local_column_sort");

    if (taskid == MASTER) {
        int* sorted_data_padded = (int*)malloc(N_padded * sizeof(int));
        memcpy(&sorted_data_padded[0], local_array, rows * sizeof(int));

        for (int p = 1; p < P; ++p) {
            MPI_Recv(&sorted_data_padded[p * rows], rows, MPI_INT, p, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        int* sorted_data = (int*)malloc(N * sizeof(int));
        memcpy(sorted_data, sorted_data_padded, N * sizeof(int));

        // Verify that the array is sorted
        printf("Sorted array: ");
        for (int i = 0; i < N; ++i) {
            printf("%d ", sorted_data[i]);
        }
        printf("\n");

        free(sorted_data);
        free(sorted_data_padded);
    } else {
        MPI_Send(local_array, rows, MPI_INT, MASTER, 0, MPI_COMM_WORLD);
    }

    free(local_array);
    MPI_Finalize();
    return 0;
}
